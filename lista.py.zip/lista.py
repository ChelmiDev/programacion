lista = range(1,101)


for i in reversed(lista):
    print(i)